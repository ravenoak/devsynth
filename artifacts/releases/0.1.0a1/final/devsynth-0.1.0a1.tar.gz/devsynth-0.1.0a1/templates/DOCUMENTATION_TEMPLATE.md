---
title: "Document Title"
date: "YYYY-MM-DD"
version: "0.1.0-alpha.1"
tags:
  - "tag1"
  - "tag2"
  - "tag3"
status: "draft|active|review|approved|archived"
author: "Author Name"
last_reviewed: "YYYY-MM-DD"
---

# Document Title

## Overview

Brief description of the document's purpose and content.

## Section 1

Content for section 1.

## Section 2

Content for section 2.

## Section 3

Content for section 3.

## Related Documents

- [Document 1](path/to/document1.md)
- [Document 2](path/to/document2.md)

## Changelog

| Date | Version | Changes | Author |
|------|---------|---------|--------|
| YYYY-MM-DD | 1.0.0 | Initial version | Author Name |
