# Boundary Values Edge Case Template

Prompt the model to generate tests that exercise minimum and maximum limits, off-by-one scenarios, empty collections, negative numbers, and zero. Each test should probe the value at the boundary and just beyond it to confirm correct handling.
