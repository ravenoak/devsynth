"""Generated modules for DevSynth."""

from __future__ import annotations

__all__ = [
    "feature_markers_enum",
]
