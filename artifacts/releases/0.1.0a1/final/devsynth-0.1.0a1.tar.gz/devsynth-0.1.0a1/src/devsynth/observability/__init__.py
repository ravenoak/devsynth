"""Observability helpers (metrics, logging hooks).

This package intentionally keeps dependencies optional and surfaces no-ops when
extras are not installed.
"""
