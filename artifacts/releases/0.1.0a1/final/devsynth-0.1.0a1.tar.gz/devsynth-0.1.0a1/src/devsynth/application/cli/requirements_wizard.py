"""CLI entry point for the requirements wizard."""

from devsynth.application.requirements.wizard import requirements_wizard

__all__ = ["requirements_wizard"]
