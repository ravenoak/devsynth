"""
Adapters for requirements management.
"""
