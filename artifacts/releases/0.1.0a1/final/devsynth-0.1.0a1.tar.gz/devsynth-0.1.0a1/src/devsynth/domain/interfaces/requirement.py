"""Domain interfaces for requirements management."""

from __future__ import annotations

from uuid import UUID

from devsynth.application.requirements.models import (
    ChangeNotificationPayload,
    EDRRPhase,
    ImpactNotificationPayload,
)
from devsynth.domain.models.requirement import (
    ChatMessage,
    ChatSession,
    DialecticalReasoning,
    ImpactAssessment,
    Requirement,
    RequirementChange,
)
from devsynth.logging_setup import DevSynthLogger

logger = DevSynthLogger(__name__)


class RequirementRepositoryInterface:
    """Simple in-memory requirement repository."""

    def __init__(self) -> None:
        self.requirements: dict[UUID, Requirement] = {}

    def get_requirement(self, requirement_id: UUID) -> Requirement | None:
        return self.requirements.get(requirement_id)

    def get_all_requirements(self) -> list[Requirement]:
        return list(self.requirements.values())

    def save_requirement(self, requirement: Requirement) -> Requirement:
        self.requirements[requirement.id] = requirement
        return requirement

    def delete_requirement(self, requirement_id: UUID) -> bool:
        if requirement_id in self.requirements:
            del self.requirements[requirement_id]
            return True
        return False

    def get_requirements_by_status(self, status: str) -> list[Requirement]:
        return [r for r in self.requirements.values() if r.status.value == status]

    def get_requirements_by_type(self, type_: str) -> list[Requirement]:
        return [r for r in self.requirements.values() if r.type.value == type_]


class ChangeRepositoryInterface:
    """Simple in-memory repository for requirement changes."""

    def __init__(self) -> None:
        self.changes: dict[UUID, RequirementChange] = {}

    def get_change(self, change_id: UUID) -> RequirementChange | None:
        return self.changes.get(change_id)

    def get_changes_for_requirement(
        self, requirement_id: UUID
    ) -> list[RequirementChange]:
        return [c for c in self.changes.values() if c.requirement_id == requirement_id]

    def save_change(self, change: RequirementChange) -> RequirementChange:
        self.changes[change.id] = change
        return change

    def delete_change(self, change_id: UUID) -> bool:
        if change_id in self.changes:
            del self.changes[change_id]
            return True
        return False


class ImpactAssessmentRepositoryInterface:
    """Simple in-memory impact assessment repository."""

    def __init__(self) -> None:
        self.assessments: dict[UUID, ImpactAssessment] = {}
        self.change_to_assessment: dict[UUID, UUID] = {}

    def get_impact_assessment(self, assessment_id: UUID) -> ImpactAssessment | None:
        return self.assessments.get(assessment_id)

    def get_impact_assessment_for_change(
        self, change_id: UUID
    ) -> ImpactAssessment | None:
        assessment_id = self.change_to_assessment.get(change_id)
        if assessment_id:
            return self.assessments.get(assessment_id)
        return None

    def save_impact_assessment(self, assessment: ImpactAssessment) -> ImpactAssessment:
        self.assessments[assessment.id] = assessment
        if assessment.change_id:
            self.change_to_assessment[assessment.change_id] = assessment.id
        return assessment


class DialecticalReasoningRepositoryInterface:
    """Simple in-memory dialectical reasoning repository."""

    def __init__(self) -> None:
        self.reasonings: dict[UUID, DialecticalReasoning] = {}
        self.change_to_reasoning: dict[UUID, UUID] = {}

    def get_reasoning(self, reasoning_id: UUID) -> DialecticalReasoning | None:
        return self.reasonings.get(reasoning_id)

    def get_reasoning_for_change(self, change_id: UUID) -> DialecticalReasoning | None:
        reasoning_id = self.change_to_reasoning.get(change_id)
        if reasoning_id:
            return self.reasonings.get(reasoning_id)
        return None

    def save_reasoning(self, reasoning: DialecticalReasoning) -> DialecticalReasoning:
        self.reasonings[reasoning.id] = reasoning
        if reasoning.change_id:
            self.change_to_reasoning[reasoning.change_id] = reasoning.id
        return reasoning


class ChatRepositoryInterface:
    """Simple in-memory chat repository."""

    def __init__(self) -> None:
        self.sessions: dict[UUID, ChatSession] = {}
        self.messages: dict[UUID, ChatMessage] = {}
        self.user_sessions: dict[str, list[UUID]] = {}

    def get_session(self, session_id: UUID) -> ChatSession | None:
        return self.sessions.get(session_id)

    def get_sessions_for_user(self, user_id: str) -> list[ChatSession]:
        session_ids = self.user_sessions.get(user_id, [])
        return [self.sessions[sid] for sid in session_ids if sid in self.sessions]

    def save_session(self, session: ChatSession) -> ChatSession:
        self.sessions[session.id] = session
        self.user_sessions.setdefault(session.user_id, [])
        if session.id not in self.user_sessions[session.user_id]:
            self.user_sessions[session.user_id].append(session.id)
        return session

    def save_message(self, message: ChatMessage) -> ChatMessage:
        self.messages[message.id] = message
        return message

    def get_messages_for_session(self, session_id: UUID) -> list[ChatMessage]:
        return [m for m in self.messages.values() if m.session_id == session_id]


class DialecticalReasonerInterface:
    """Base dialectical reasoner implementation."""

    def evaluate_change(
        self,
        change: RequirementChange,
        edrr_phase: EDRRPhase = EDRRPhase.REFINE,
    ) -> DialecticalReasoning:
        reasoning = DialecticalReasoning(change_id=change.id)
        reasoning.thesis = f"Proposed change {change.id}"
        reasoning.antithesis = "Opposing view"
        reasoning.synthesis = "Synthesis"
        reasoning.conclusion = "Unreviewed"
        reasoning.recommendation = "Review"
        return reasoning

    def process_message(
        self, session_id: UUID, message: str, user_id: str
    ) -> ChatMessage:
        return ChatMessage(session_id=session_id, sender="system", content=message)

    def create_session(
        self, user_id: str, change_id: UUID | None = None
    ) -> ChatSession:
        return ChatSession(user_id=user_id, change_id=change_id)

    def assess_impact(
        self,
        change: RequirementChange,
        edrr_phase: EDRRPhase = EDRRPhase.REFINE,
    ) -> ImpactAssessment:
        return ImpactAssessment(change_id=change.id, analysis="")


class NotificationInterface:
    """Base notification service."""

    def notify_change_proposed(self, payload: ChangeNotificationPayload) -> None:
        logger.info("Change proposed: %s", payload.change.id)

    def notify_change_approved(self, payload: ChangeNotificationPayload) -> None:
        logger.info("Change approved: %s", payload.change.id)

    def notify_change_rejected(self, payload: ChangeNotificationPayload) -> None:
        logger.warning("Change rejected: %s", payload.change.id)

    def notify_impact_assessment_completed(
        self, payload: ImpactNotificationPayload
    ) -> None:
        logger.info("Impact assessment completed: %s", payload.assessment.id)


class InMemoryRequirementRepository(RequirementRepositoryInterface):
    """In-memory implementation of :class:`RequirementRepositoryInterface`."""

    def __init__(self) -> None:
        super().__init__()


class InMemoryChangeRepository(ChangeRepositoryInterface):
    """In-memory implementation of :class:`ChangeRepositoryInterface`."""

    def __init__(self) -> None:
        super().__init__()


class InMemoryImpactAssessmentRepository(ImpactAssessmentRepositoryInterface):
    """In-memory implementation of :class:`ImpactAssessmentRepositoryInterface`."""

    def __init__(self) -> None:
        super().__init__()


class InMemoryDialecticalReasoningRepository(DialecticalReasoningRepositoryInterface):
    """In-memory implementation of :class:`DialecticalReasoningRepositoryInterface`."""

    def __init__(self) -> None:
        super().__init__()


class InMemoryChatRepository(ChatRepositoryInterface):
    """In-memory implementation of :class:`ChatRepositoryInterface`."""

    def __init__(self) -> None:
        super().__init__()


class SimpleDialecticalReasoner(DialecticalReasonerInterface):
    """Minimal implementation of :class:`DialecticalReasonerInterface`."""

    def __init__(self, chat_repo: ChatRepositoryInterface) -> None:
        self.chat_repo = chat_repo

    def evaluate_change(
        self,
        change: RequirementChange,
        edrr_phase: EDRRPhase = EDRRPhase.REFINE,
    ) -> DialecticalReasoning:
        reasoning = DialecticalReasoning(change_id=change.id)
        reasoning.thesis = f"Proposed change {change.id}"
        reasoning.antithesis = "Opposing view"
        reasoning.synthesis = "Synthesis"
        reasoning.conclusion = "Unreviewed"
        reasoning.recommendation = "Review"
        return reasoning

    def process_message(
        self, session_id: UUID, message: str, user_id: str
    ) -> ChatMessage:
        session = self.chat_repo.get_session(session_id)
        if not session:
            raise ValueError(f"Session {session_id} not found")
        user_msg = ChatMessage(session_id=session_id, sender=user_id, content=message)
        self.chat_repo.save_message(user_msg)
        response = ChatMessage(session_id=session_id, sender="system", content=message)
        self.chat_repo.save_message(response)
        return response

    def create_session(
        self, user_id: str, change_id: UUID | None = None
    ) -> ChatSession:
        session = ChatSession(user_id=user_id, change_id=change_id)
        self.chat_repo.save_session(session)
        return session

    def assess_impact(
        self,
        change: RequirementChange,
        edrr_phase: EDRRPhase = EDRRPhase.REFINE,
    ) -> ImpactAssessment:
        assessment = ImpactAssessment(change_id=change.id, analysis="None")
        return assessment


class PrintNotificationService(NotificationInterface):
    """Simple notification service that prints messages to stdout."""

    def notify_change_proposed(self, payload: ChangeNotificationPayload) -> None:
        print(f"Change proposed: {payload.change.id}")

    def notify_change_approved(self, payload: ChangeNotificationPayload) -> None:
        print(f"Change approved: {payload.change.id}")

    def notify_change_rejected(self, payload: ChangeNotificationPayload) -> None:
        print(f"Change rejected: {payload.change.id}")

    def notify_impact_assessment_completed(
        self, payload: ImpactNotificationPayload
    ) -> None:
        print(f"Impact assessment completed: {payload.assessment.id}")
