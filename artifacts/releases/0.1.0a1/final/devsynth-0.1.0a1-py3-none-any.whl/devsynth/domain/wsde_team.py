"""WSDE team domain module with cross-store synchronization."""

from .models.wsde_facade import WSDETeam

__all__ = ["WSDETeam"]
