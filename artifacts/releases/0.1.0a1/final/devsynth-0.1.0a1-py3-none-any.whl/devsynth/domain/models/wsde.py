"""Compatibility shim for legacy WSDE imports."""

from .wsde_facade import WSDE, WSDETeam

__all__ = ["WSDE", "WSDETeam"]
