"""Deprecated: moved to devsynth.interface.ux_bridge."""

from devsynth.interface.ux_bridge import UXBridge

__all__ = ["UXBridge"]
