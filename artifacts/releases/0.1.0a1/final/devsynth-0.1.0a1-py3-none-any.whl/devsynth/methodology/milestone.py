"""Milestone methodology adapter for DevSynth.

This adapter integrates EDRR with milestone-based development requiring
formal approvals.
"""

import datetime
from typing import Any

from devsynth.logging_setup import DevSynthLogger
from devsynth.methodology.base import BaseMethodologyAdapter, Phase

logger = DevSynthLogger(__name__)


class MilestoneAdapter(BaseMethodologyAdapter):
    """Adapter for milestone-driven workflows with approval gates."""

    def __init__(self, config: dict[str, Any]):
        super().__init__(config)
        settings = self.config.get("settings", {})
        self.approval_required: dict[str, bool] = settings.get("approvalRequired", {})
        self.approvers: list[str] = settings.get("approvers", [])

    def should_start_cycle(self) -> bool:
        return True

    def should_progress_to_next_phase(
        self, current_phase: Phase, context: dict[str, Any], results: dict[str, Any]
    ) -> bool:
        if not bool(results.get("phase_complete")):
            return False
        key = f"after{current_phase.name.title()}"
        if self.approval_required.get(key, False):
            return bool(results.get("approved", False))
        return True

    def before_cycle(self) -> dict[str, Any]:
        return {"milestone_start": datetime.datetime.now().isoformat()}

    def after_cycle(self, results: dict[str, Any]) -> None:
        results["milestone_complete"] = True

    def generate_reports(self, cycle_results: dict[str, Any]) -> list[dict[str, Any]]:
        return [
            {
                "title": "Milestone Compliance Report",
                "type": "milestone_report",
                "content": {
                    "approvers": self.approvers,
                    "approval_required": self.approval_required,
                },
            }
        ]
