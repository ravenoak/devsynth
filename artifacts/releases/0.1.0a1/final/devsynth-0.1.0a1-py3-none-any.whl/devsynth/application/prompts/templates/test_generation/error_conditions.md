# Error Conditions Edge Case Template

Encourage the model to generate tests that simulate invalid inputs, missing resources, permission issues, and network failures. Each scenario should assert the exact exception type and message or error code returned.
